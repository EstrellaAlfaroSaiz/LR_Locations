# -*- coding: utf-8 -*-
"""Preview occurrence groups and document plausible threats."""
import math
from collections import defaultdict
from itertools import combinations
from pathlib import Path

try:
    from qgis.PyQt.QtWidgets import QAction
except ImportError:
    from qgis.PyQt.QtGui import QAction

from qgis.PyQt.QtCore import Qt, QVariant, QUrl
from qgis.PyQt.QtGui import QColor, QIntValidator
from qgis.PyQt.QtWidgets import (
    QComboBox, QDialog, QDoubleSpinBox, QFormLayout, QHBoxLayout, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QPlainTextEdit,
    QPushButton, QScrollArea, QSpinBox, QTextBrowser, QVBoxLayout, QWidget,
)
from qgis.core import (
    NULL, Qgis, QgsCategorizedSymbolRenderer, QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsCsException, QgsFeature, QgsField, QgsGeometry,
    QgsPointXY, QgsProject, QgsRasterLayer, QgsRendererCategory, QgsSpatialIndex,
    QgsSymbol, QgsUnitTypes, QgsVectorLayer, QgsWkbTypes,
)
from qgis.gui import QgsProjectionSelectionDialog

from .threats import THREATS, THREAT_CATEGORIES
from .hydrology import derive_subbasins


NAME = "LRN IUCN Locations"
ROLE = getattr(Qt, "ItemDataRole", Qt).UserRole
CHECKED = getattr(Qt, "CheckState", Qt).Checked
UNCHECKED = getattr(Qt, "CheckState", Qt).Unchecked
CHECKABLE = getattr(Qt, "ItemFlag", Qt).ItemIsUserCheckable
GEOMETRY_TYPES = getattr(Qgis, "GeometryType", None)
POINT = GEOMETRY_TYPES.Point if GEOMETRY_TYPES is not None else QgsWkbTypes.PointGeometry
POLYGON = GEOMETRY_TYPES.Polygon if GEOMETRY_TYPES is not None else QgsWkbTypes.PolygonGeometry


class LrnIucnLocalitiesPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        self.action = QAction(NAME, self.iface.mainWindow())
        self.action.setToolTip("ES: Previsualiza agrupaciones de registros y documenta la amenaza plausible.")
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(NAME, self.action)

    def unload(self):
        if self.dialog:
            self.dialog.remove_preview()
            self.dialog.close()
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu(NAME, self.action)

    def run(self):
        if self.dialog is None:
            self.dialog = LocalitiesDialog(self.iface)
        self.dialog.refresh_layers()
        self.dialog.show()
        self.dialog.raise_()


def group_points(points, distance):
    """Group records linked by a chain of neighbours within the distance."""
    parents = list(range(len(points)))

    def root(index):
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    grid = defaultdict(list)
    for i, point in enumerate(points):
        x, y = point.x(), point.y()
        col, row = math.floor(x / distance), math.floor(y / distance)
        for a in range(col - 1, col + 2):
            for b in range(row - 1, row + 2):
                for j in grid[a, b]:
                    other = points[j]
                    if (x - other.x()) ** 2 + (y - other.y()) ** 2 <= distance ** 2:
                        parents[root(i)] = root(j)
        grid[col, row].append(i)
    groups = defaultdict(list)
    for i in range(len(points)):
        groups[root(i)].append(i)
    return list(groups.values())


HABITAT_RULES = ("habitat", "habitat_basin", "within_habitat", "within_habitat_basin")
BASIN_RULES = ("within_basin", "occupied_basins", "habitat_basin", "within_habitat_basin")
DISTANCE_RULES = ("distance", "within_basin", "within_habitat", "within_habitat_basin")


def group_by_units(points, memberships, distance=None):
    """Group uniquely assigned occurrences, optionally linking by distance within each unit."""
    buckets = defaultdict(list)
    unassigned = []
    for i, units in enumerate(zip(*memberships)):
        if all(unit and len(unit) == 1 for unit in units):
            buckets[units].append(i)
        else:
            unassigned.append(i)
    if distance is None:
        return list(buckets.values()), unassigned
    groups = []
    for indices in buckets.values():
        groups.extend([indices[i] for i in group]
                      for group in group_points([points[i] for i in indices], distance))
    return sorted(groups, key=min), unassigned


def terrain_position(point, sample, radius, threshold):
    """Approximate TPI using two rings of evenly spaced elevation samples."""
    center = sample(point)
    if center is None:
        return None
    neighbours = []
    for angle_index in range(8):
        angle = angle_index * math.pi / 4
        direction = []
        for factor in (0.5, 1.0):
            step = radius * factor
            value = sample(QgsPointXY(point.x() + step * math.cos(angle),
                                      point.y() + step * math.sin(angle)))
            if value is not None:
                direction.append(value)
        if not direction:
            return None
        neighbours.append(sum(direction) / len(direction))
    tpi = center - sum(neighbours) / len(neighbours)
    label = "Ridge" if tpi >= threshold else "Valley bottom" if tpi <= -threshold else "Intermediate"
    return center, tpi, label


def _layer(name, geometry, crs, fields):
    layer = QgsVectorLayer(geometry, name, "memory")
    if crs is not None:
        layer.setCrs(crs)
    if fields and not layer.dataProvider().addAttributes([QgsField(key, kind) for key, kind in fields]):
        raise RuntimeError(f"Could not create fields for {name}.")
    layer.updateFields()
    layer.setCustomProperty("lrn_location_output", True)
    return layer


def _add_rows(layer, rows):
    features = []
    for geometry, values in rows:
        feature = QgsFeature(layer.fields())
        if geometry is not None:
            feature.setGeometry(geometry)
        feature.setAttributes(values)
        features.append(feature)
    if features and not layer.dataProvider().addFeatures(features)[0]:
        raise RuntimeError(f"Could not populate {layer.name()}.")
    layer.updateExtents()


def _style(layer, labels):
    categories = []
    for index, label in enumerate(labels):
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        symbol.setColor(QColor.fromHsv((index * 137 + 208) % 360, 170, 215))
        if layer.geometryType() == POLYGON:
            symbol.setOpacity(0.45)
        categories.append(QgsRendererCategory(label, symbol, label))
    layer.setRenderer(QgsCategorizedSymbolRenderer("group_id", categories))


class LocalitiesDialog(QDialog):
    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.project = QgsProject.instance()
        self.preview_ids = []
        self.hydrology_cache = None
        self.crs = QgsCoordinateReferenceSystem("EPSG:3035")
        self.setWindowTitle(NAME)
        self.resize(790, 760)
        outer = QVBoxLayout(self)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        scroll.setWidget(content)
        outer.addWidget(scroll)
        layout = QVBoxLayout(content)
        intro = QLabel("Preview groups by distance, habitat or sub-basin and review the plausible threatening event.")
        intro.setWordWrap(True)
        layout.addWidget(intro)
        self.layers = QListWidget()
        self.layers.setMinimumHeight(115)
        self.layers.setToolTip("EN: Check the point layers to group. All records in those layers are used.\nES: Marca las capas de puntos que quieres agrupar. Se utilizan todos sus registros.")
        layout.addWidget(self.layers)
        row = QHBoxLayout()
        self._button(row, "Refresh layers", "Actualiza la lista de capas del proyecto.", self.refresh_layers)
        self._button(row, "Select all point layers", "Marca todas las capas de puntos disponibles.", self.select_all)
        layout.addLayout(row)

        form = QFormLayout()
        layout.addLayout(form)
        self.threat = QComboBox()
        self.threat.addItem("Select a threat category...", None)
        for category in THREAT_CATEGORIES:
            self._add_threat_option(self.threat, category)
        self._field(form, "Threat (IUCN-CMP)", self.threat, "Selecciona una categoría principal de amenazas.")
        self.subthreat = QComboBox()
        self._field(form, "Sub-threat", self.subthreat, "Selecciona el código concreto dentro de la amenaza elegida.")
        self.threat.currentIndexChanged.connect(self._refresh_subthreats)
        self.subthreat.currentIndexChanged.connect(self._update_threat_help)
        self._refresh_subthreats()
        self.event = QLineEdit()
        self._field(form, "Plausible event", self.event, "Describe el evento concreto que podría afectar rápidamente a los registros.",
                    "Describe the single plausible event that could rapidly affect the occurrences")
        self.justification = QLineEdit()
        self._field(form, "Grouping justification", self.justification, "Explica por qué la regla elegida aproxima el alcance del evento.",
                    "Explain why the selected rule approximates the extent of the event")
        self.distance = QComboBox()
        self.distance.setEditable(True)
        self.distance.addItems(["500", *(str(m) for m in range(1000, 200001, 1000))])
        self.distance.setValidator(QIntValidator(1, 1000000, self.distance))
        self.distance.setMaxVisibleItems(15)
        self._field(form, "Link distance (m)", self.distance,
                    "Distancia en metros entre vecinos enlazados. Puedes escribir otro valor. "
                    "Una cadena puede conectar extremos más alejados.",
                    "Maximum link between neighbours in metres. Chains may span longer distances")
        self.crs_button = QPushButton("Change CRS (EPSG:3035)")
        self.crs_button.clicked.connect(self.choose_crs)
        self._field(form, "Analysis CRS", self.crs_button, "Usa un sistema proyectado en metros adecuado para tu zona.")
        self.support = QComboBox()
        for label, value in (("None", "none"), ("Elevation range", "elevation"),
                             ("Elevation difference", "relief"), ("Ridges and valley bottoms (TPI)", "tpi"),
                             ("Existing watershed polygons", "basins"), ("Derive sub-basins from DEM", "derived_basins")):
            self.support.addItem(label, value)
        self._field(form, "Terrain support", self.support, "Consulta el relieve o elige cuencas para comparar dos agrupaciones.",
                    "View terrain context or choose basins to compare two grouping scenarios")
        self.terrain = QComboBox()
        self._field(form, "Terrain layer", self.terrain, "Selecciona un MDT (banda 1, metros) o una capa de polígonos de cuencas.",
                    "Choose band 1 of a DEM with elevations in metres, or a watershed polygon layer")
        self.tpi_radius = QDoubleSpinBox()
        self.tpi_radius.setRange(1, 100000)
        self.tpi_radius.setDecimals(0)
        self.tpi_radius.setValue(1000)
        self.tpi_radius.setSuffix(" m")
        self._field(form, "Terrain neighbourhood", self.tpi_radius,
                    "Radio de muestreo del relieve. Cambiarlo puede distinguir una cresta local de una divisoria amplia.")
        self.tpi_threshold = QDoubleSpinBox()
        self.tpi_threshold.setRange(0.1, 5000)
        self.tpi_threshold.setValue(10)
        self.tpi_threshold.setSuffix(" m")
        self._field(form, "Minimum elevation contrast", self.tpi_threshold,
                    "Diferencia mínima respecto al entorno para clasificar el punto como cresta o vaguada probable.")
        self.basin_field = QComboBox()
        self._field(form, "Basin ID field", self.basin_field, "Campo que identifica cada cuenca. Sin campo se usa el ID de la entidad.")
        self.basin_threshold = QSpinBox()
        self.basin_threshold.setRange(1, 100000000)
        self.basin_threshold.setValue(1000)
        self.basin_threshold.setSuffix(" cells")
        self._field(form, "Minimum basin size", self.basin_threshold,
                    "Umbral de acumulación en celdas del MDT. Un valor menor puede producir subcuencas más pequeñas.",
                    "Flow accumulation threshold in DEM cells. Lower values can produce smaller sub-basins.")
        self.habitat_layer = QComboBox()
        self.habitat_field = QComboBox()
        self.habitat_value = QComboBox()
        self._field(form, "Habitat polygons", self.habitat_layer, "Elige la capa de hábitats.")
        self._field(form, "Habitat field", self.habitat_field, "Elige el campo con el código o nombre del hábitat.")
        self._field(form, "Habitat class", self.habitat_value, "Elige el hábitat que se usará para delimitar manchas.")
        self.habitat_layer.currentIndexChanged.connect(self.refresh_habitat_fields)
        self.habitat_field.currentIndexChanged.connect(self.refresh_habitat_values)
        self.grouping_rule = QComboBox()
        self.grouping_rule.addItem("Distance only", "distance")
        self.grouping_rule.addItem("Distance within each sub-basin", "within_basin")
        self.grouping_rule.addItem("Occupied sub-basins", "occupied_basins")
        self.grouping_rule.addItem("Occupied habitat patches", "habitat")
        self.grouping_rule.addItem("Habitat patches within sub-basins", "habitat_basin")
        self.grouping_rule.addItem("Distance within each habitat patch", "within_habitat")
        self.grouping_rule.addItem("Distance within habitat patches and sub-basins", "within_habitat_basin")
        self._field(form, "Grouping rule", self.grouping_rule,
                    "La misma regla se usa para previsualizar y generar los grupos finales.",
                    "The selected rule drives both the preview and the final groups.")
        self.support.currentIndexChanged.connect(self.refresh_terrain)
        self.terrain.currentIndexChanged.connect(self.refresh_basin_fields)

        actions = QHBoxLayout()
        self._button(actions, "Preview groups", "Dibuja temporalmente las manchas, muestra el recuento y el resumen por grupo.", lambda: self.calculate(True), "Draw temporary patches and compare group counts")
        self._button(actions, "Clear preview", "Retira las capas temporales de la vista previa.", self.remove_preview, "Remove all temporary scenario and terrain layers")
        self._button(actions, "Generate final locations", "Añade al proyecto las manchas revisadas, los puntos asignados y la tabla resumen.", lambda: self.calculate(False), "Keep the outputs for the selected grouping rule")
        self._button(actions, "Distance references", "Abre la bibliografía para justificar el alcance de los eventos.",
                     self.show_references, "Read the evidence for choosing an event distance")
        layout.addLayout(actions)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(115)
        layout.addWidget(self.log)
        self.refresh_layers()

    def show_references(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Distance references")
        dialog.resize(760, 580)
        layout = QVBoxLayout(dialog)
        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        browser.setSource(QUrl.fromLocalFile(str(Path(__file__).with_name("REFERENCES.html"))))
        layout.addWidget(browser)
        execute = dialog.exec if hasattr(dialog, "exec") else dialog.exec_
        execute()

    def _button(self, layout, label, tip, action, english=None):
        button = QPushButton(label)
        button.setToolTip(f"EN: {english or label}.\nES: {tip}")
        button.clicked.connect(action)
        layout.addWidget(button)

    def _field(self, form, label, control, tip, english=None):
        control.setToolTip(f"EN: {english or label}.\nES: {tip}")
        form.addRow(label, control)
        form.labelForField(control).setToolTip(control.toolTip())

    def _add_threat_option(self, combo, option):
        combo.addItem(f"{option[0]} - {option[1]}", option)
        combo.setItemData(combo.count() - 1, f"EN: {option[1]}\nES: {option[2]}", getattr(Qt, "ItemDataRole", Qt).ToolTipRole)

    def _refresh_subthreats(self):
        category = self.threat.currentData()
        self.subthreat.clear()
        self.subthreat.addItem("Select a sub-threat...", None)
        if category:
            self.threat.setToolTip(f"EN: {category[1]}\nES: {category[2]}")
            for threat in THREATS:
                if threat[0].startswith(category[0] + "."):
                    self._add_threat_option(self.subthreat, threat)
        else:
            self.threat.setToolTip("EN: Choose a threat category.\nES: Selecciona una categoría principal de amenazas.")
        self.subthreat.setEnabled(category is not None)

    def _update_threat_help(self):
        threat = self.subthreat.currentData()
        self.subthreat.setToolTip(f"EN: {threat[1]}\nES: {threat[2]}" if threat else "EN: Choose a sub-threat.\nES: Selecciona una subamenaza de la lista.")

    def _distance_value(self):
        if not self.distance.lineEdit().hasAcceptableInput():
            raise ValueError("Enter a link distance between 1 and 1,000,000 metres.")
        return self.distance.validator().locale().toInt(self.distance.currentText())[0]

    def choose_crs(self):
        selector = QgsProjectionSelectionDialog(self)
        selector.setCrs(self.crs)
        execute = selector.exec if hasattr(selector, "exec") else selector.exec_
        if execute():
            crs = selector.crs()
            units = getattr(getattr(Qgis, "DistanceUnit", None), "Meters", QgsUnitTypes.DistanceMeters)
            if not crs.isValid() or crs.isGeographic() or crs.mapUnits() != units:
                QMessageBox.warning(self, NAME, "Choose a projected CRS with metres as the map unit.")
                return
            self.crs = crs
            self.crs_button.setText(f"Change CRS ({crs.authid() or crs.description()})")

    def _selected_layer_ids(self):
        return {self.layers.item(i).data(ROLE) for i in range(self.layers.count())
                if self.layers.item(i).checkState() == CHECKED}

    def refresh_layers(self):
        selected = self._selected_layer_ids()
        self.layers.clear()
        for layer in self.project.mapLayers().values():
            if (not isinstance(layer, QgsVectorLayer) or not layer.isValid()
                    or layer.geometryType() != POINT
                    or layer.customProperty("lrn_location_output")
                    or layer.customProperty("aoo_eoo_gbif_pro_layer_type") == "gbif_preview"):
                continue
            item = QListWidgetItem(layer.name())
            item.setData(ROLE, layer.id())
            item.setFlags(item.flags() | CHECKABLE)
            item.setCheckState(CHECKED if layer.id() in selected else UNCHECKED)
            self.layers.addItem(item)
        previous = self.habitat_layer.currentData()
        self.habitat_layer.blockSignals(True)
        self.habitat_layer.clear()
        self.habitat_layer.addItem("None", None)
        for layer in self.project.mapLayers().values():
            if (isinstance(layer, QgsVectorLayer) and layer.isValid()
                    and layer.geometryType() == POLYGON and not layer.customProperty("lrn_location_output")):
                self.habitat_layer.addItem(layer.name(), layer.id())
        self.habitat_layer.setCurrentIndex(max(0, self.habitat_layer.findData(previous)))
        self.habitat_layer.blockSignals(False)
        self.refresh_habitat_fields()
        self.refresh_terrain()

    def refresh_habitat_fields(self):
        layer = self.project.mapLayer(self.habitat_layer.currentData() or "")
        previous = self.habitat_field.currentText()
        self.habitat_field.blockSignals(True)
        self.habitat_field.clear()
        if layer:
            self.habitat_field.addItems([field.name() for field in layer.fields()])
            self.habitat_field.setCurrentIndex(max(0, self.habitat_field.findText(previous)))
        self.habitat_field.blockSignals(False)
        self.refresh_habitat_values()

    def refresh_habitat_values(self):
        layer = self.project.mapLayer(self.habitat_layer.currentData() or "")
        previous = self.habitat_value.currentData()
        self.habitat_value.clear()
        if not layer or not self.habitat_field.currentText():
            return
        index = layer.fields().indexFromName(self.habitat_field.currentText())
        values = (value for value in layer.uniqueValues(index) if value is not None and value != NULL)
        for value in sorted(values, key=str):
            self.habitat_value.addItem(str(value), value)
        self.habitat_value.setCurrentIndex(max(0, self.habitat_value.findData(previous)))

    def habitat_assignments(self, points):
        layer = self.project.mapLayer(self.habitat_layer.currentData() or "")
        field = self.habitat_field.currentText()
        selected = self.habitat_value.currentData()
        if not layer or not layer.crs().isValid() or not field or selected is None:
            raise ValueError("Select a habitat polygon layer with a defined CRS, a field and a class.")
        geometries = []
        for feature in layer.getFeatures():
            if feature[field] != selected or not feature.hasGeometry():
                continue
            geometry = feature.geometry()
            if not geometry.isGeosValid():
                raise ValueError(f"Run Fix geometries on the habitat layer (feature {feature.id()}).")
            geometries.append(geometry)
        dissolved = QgsGeometry.unaryUnion(geometries)
        if dissolved.isEmpty() or dissolved.type() != POLYGON:
            raise ValueError("The selected habitat class has no usable polygons.")
        patches = _layer("Selected habitat patches", "MultiPolygon", layer.crs(),
                         [("patch_id", QVariant.String), ("habitat", QVariant.String)])
        rows = []
        for i, geometry in enumerate(dissolved.asGeometryCollection(), 1):
            geometry.convertToMultiType()
            rows.append((geometry, [f"H{i:03d}", str(selected)]))
        _add_rows(patches, rows)
        flags = getattr(QgsSpatialIndex, "Flag", QgsSpatialIndex)
        index = QgsSpatialIndex(patches.getFeatures(), flags=flags.FlagStoreFeatureGeometries)
        labels = {feature.id(): feature["patch_id"] for feature in patches.getFeatures()}
        transform = QgsCoordinateTransform(self.crs, layer.crs(), self.project)
        assignments = []
        for point in points:
            geometry = QgsGeometry.fromPointXY(transform.transform(point))
            assignments.append(tuple(sorted(labels[fid] for fid in index.intersects(geometry.boundingBox())
                                            if index.geometry(fid).intersects(geometry))))
        return assignments, patches

    def select_all(self):
        for i in range(self.layers.count()):
            self.layers.item(i).setCheckState(CHECKED)

    def refresh_terrain(self):
        mode = self.support.currentData()
        previous = self.terrain.currentData()
        self.terrain.blockSignals(True)
        self.terrain.clear()
        if mode != "none":
            for layer in self.project.mapLayers().values():
                is_basin = isinstance(layer, QgsVectorLayer) and layer.geometryType() == POLYGON
                if layer.isValid() and not layer.customProperty("lrn_location_output") and (is_basin if mode == "basins" else isinstance(layer, QgsRasterLayer)):
                    self.terrain.addItem(layer.name(), layer.id())
        index = self.terrain.findData(previous)
        if index >= 0:
            self.terrain.setCurrentIndex(index)
        self.terrain.blockSignals(False)
        self.terrain.setEnabled(mode != "none")
        self.basin_threshold.setEnabled(mode == "derived_basins")
        self.tpi_radius.setEnabled(mode == "tpi")
        self.tpi_threshold.setEnabled(mode == "tpi")
        self.refresh_basin_fields()

    def refresh_basin_fields(self):
        previous = self.basin_field.currentText()
        self.basin_field.clear()
        self.basin_field.addItem("Feature ID", None)
        layer = self.project.mapLayer(self.terrain.currentData() or "")
        if self.support.currentData() == "basins" and isinstance(layer, QgsVectorLayer):
            for field in layer.fields():
                self.basin_field.addItem(field.name(), field.name())
            index = self.basin_field.findText(previous)
            if index >= 0:
                self.basin_field.setCurrentIndex(index)
        self.basin_field.setEnabled(self.support.currentData() == "basins")

    def collect_points(self):
        records = []
        for layer_id in sorted(self._selected_layer_ids()):
            layer = self.project.mapLayer(layer_id)
            if layer is None:
                continue
            if not layer.crs().isValid():
                raise ValueError(f"Set a valid CRS for {layer.name()} before grouping.")
            transform = QgsCoordinateTransform(layer.crs(), self.crs, self.project)
            for feature in layer.getFeatures():
                geom = feature.geometry()
                if not geom or geom.isEmpty():
                    continue
                source = geom.asMultiPoint() if geom.isMultipart() else [geom.asPoint()]
                for point in source:
                    point = transform.transform(QgsPointXY(point))
                    if math.isfinite(point.x()) and math.isfinite(point.y()):
                        records.append((point, layer.name(), str(feature.id())))
        return records

    def _terrain_values(self, points):
        mode = self.support.currentData()
        if mode == "none":
            return [None] * len(points), ""
        layer = self.project.mapLayer(self.terrain.currentData() or "")
        if layer is None or not layer.isValid() or not layer.crs().isValid():
            raise ValueError("Select a valid terrain support layer with a defined CRS.")
        if mode == "derived_basins":
            key = (layer.id(), layer.source(), self.basin_threshold.value())
            if self.hydrology_cache is None or self.hydrology_cache[0] != key:
                basins, streams = derive_subbasins(layer, self.basin_threshold.value())
                self.hydrology_cache = (key, basins.source(), streams.source())
            basins = QgsRasterLayer(self.hydrology_cache[1], "DEM sub-basins")
            transform = QgsCoordinateTransform(self.crs, basins.crs(), self.project)
            provider = basins.dataProvider()
            extent = basins.extent()
            values = []
            for point in points:
                cell = transform.transform(point)
                if not (extent.xMinimum() <= cell.x() < extent.xMaximum()
                        and extent.yMinimum() < cell.y() <= extent.yMaximum()):
                    values.append(None)
                    continue
                value, ok = provider.sample(cell, 1)
                values.append((str(int(value)),) if ok and math.isfinite(value) and value > 0 else None)
            return values, layer.name()
        transform = QgsCoordinateTransform(self.crs, layer.crs(), self.project)
        if mode in ("elevation", "relief", "tpi"):
            provider = layer.dataProvider()
            extent = layer.extent()

            def sample(point):
                cell = transform.transform(point)
                if not (extent.xMinimum() <= cell.x() < extent.xMaximum()
                        and extent.yMinimum() < cell.y() <= extent.yMaximum()):
                    return None
                value, ok = provider.sample(cell, 1)
                return value if ok and math.isfinite(value) else None

            if mode != "tpi":
                return [sample(point) for point in points], layer.name()
            radius = self.tpi_radius.value()
            threshold = self.tpi_threshold.value()
            return [terrain_position(point, sample, radius, threshold) for point in points], layer.name()
        field = self.basin_field.currentData()
        index_flags = getattr(QgsSpatialIndex, "Flag", QgsSpatialIndex)
        spatial_index = QgsSpatialIndex(layer.getFeatures(), flags=index_flags.FlagStoreFeatureGeometries)
        labels = {feature.id(): str(feature[field] or feature.id()) if field else str(feature.id())
                  for feature in layer.getFeatures()}
        values = []
        for point in points:
            location = QgsGeometry.fromPointXY(transform.transform(point))
            hits = spatial_index.intersects(location.boundingBox())
            names = sorted({labels[fid] for fid in hits if spatial_index.geometry(fid).intersects(location)})
            values.append(tuple(names) if names else None)
        return values, layer.name()

    def remove_preview(self):
        self.project.removeMapLayers([key for key in self.preview_ids if self.project.mapLayer(key)])
        self.preview_ids.clear()
        self.log.clear()

    def calculate(self, preview):
        try:
            threat = self.subthreat.currentData()
            if not threat:
                raise ValueError("Select a threat category and a sub-threat.")
            records = self.collect_points()
            if not records:
                raise ValueError("Select at least one layer containing usable occurrence points.")
            points = [row[0] for row in records]
            rule = self.grouping_rule.currentData()
            rule_label = self.grouping_rule.currentText()
            link_distance = self._distance_value() if rule in DISTANCE_RULES else None
            comparison_distance = link_distance
            if preview and comparison_distance is None and self.distance.lineEdit().hasAcceptableInput():
                comparison_distance = self._distance_value()
            baseline = group_points(points, comparison_distance) if comparison_distance is not None else []
            basin_mode = self.support.currentData() in ("basins", "derived_basins")
            if rule in BASIN_RULES and not basin_mode:
                raise ValueError("Select existing watershed polygons or derive sub-basins from a DEM.")
            values, terrain_name = self._terrain_values(points)
            habitat_ids = None
            overlays = []
            memberships = []
            if rule in HABITAT_RULES:
                habitat_ids, habitat_patches = self.habitat_assignments(points)
                memberships.append(habitat_ids)
                overlays.append(habitat_patches)
            if rule in BASIN_RULES:
                memberships.append(values)
            groups, pending = group_by_units(points, memberships, link_distance) if memberships else (baseline, [])
            layers = self._build_outputs(records, groups, values, threat, terrain_name, preview,
                                         baseline, pending, habitat_ids=habitat_ids, distance=link_distance)
            if preview and rule != "distance" and comparison_distance is not None:
                alternate = self._build_outputs(records, baseline, values, threat, terrain_name, True,
                                                baseline, rule="distance", distance=comparison_distance)[1]
                alternate.setName("PREVIEW - distance only")
                overlays.append(alternate)
            if preview and basin_mode:
                if self.support.currentData() == "derived_basins":
                    for path, label in zip(self.hydrology_cache[1:], ("DEM sub-basins", "DEM drainage axes")):
                        raster = QgsRasterLayer(path, "PREVIEW - " + label)
                        raster.setCustomProperty("lrn_location_output", True)
                        overlays.append(raster)
        except (ValueError, RuntimeError, QgsCsException, ImportError) as exc:
            QMessageBox.warning(self, NAME, str(exc))
            return
        self.remove_preview()
        for layer in overlays:
            self.project.addMapLayer(layer)
            self.project.layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(False)
        self.project.addMapLayers(layers)
        if preview:
            self.preview_ids = [layer.id() for layer in layers + overlays]
        comparison = ""
        if preview and rule != "distance" and comparison_distance is not None:
            comparison = f"Distance-only comparison ({comparison_distance:g} m): {len(baseline)} groups\n"
        self.log.setPlainText(
            f"{rule_label}: {len(groups)} groups | Occurrences: {len(points)}\n"
            + comparison
            + f"Unassigned in current rule: {len(pending)}\n"
            + f"Threat: {threat[0]} - {threat[1]}\n"
            + ("Turn on the alternate scenario and terrain layers in the Layers panel.\n" if overlays else "")
            + "Review whether each group could be affected by the same plausible event."
        )
        self.iface.showAttributeTable(layers[-1])

    def _build_outputs(self, records, groups, values, threat, terrain_name, preview, baseline=None, pending=(), rule=None, habitat_ids=None, distance=None):
        habitat_ids = habitat_ids or [()] * len(records)
        active_rule = rule or self.grouping_rule.currentData()
        habitat_rule = active_rule in HABITAT_RULES
        habitat_class = self.habitat_value.currentText() if habitat_rule else None
        text, integer, number = QVariant.String, QVariant.Int, QVariant.Double
        prefix = "PREVIEW - " if preview else ""
        fields = [("group_id", text), ("n_points", integer), ("link_m", number), ("span_m", number),
                  ("threat", text), ("threat_name", text), ("event", text), ("rationale", text),
                  ("support", text), ("terrain", text), ("elev_min", number), ("elev_max", number),
                  ("relief_m", number), ("basins", text), ("multiple_basins", integer), ("no_data", integer),
                  ("ridge_n", integer), ("valley_n", integer), ("intermediate_n", integer),
                  ("tpi_radius_m", number), ("tpi_cutoff_m", number), ("grouping_rule", text), ("basin_cells", integer), ("habitat_class", text), ("hab_patch", text)]
        patches = _layer(prefix + ("Candidate location patches" if preview else "Location patches"), "MultiPolygon", self.crs, fields)
        summary = _layer(prefix + ("Candidate location summary" if preview else "Location summary"), "None", None, fields)
        assignments = _layer(prefix + "Assigned occurrences", "Point", self.crs,
                             [("group_id", text), ("source_layer", text), ("source_fid", text),
                              ("elevation_m", number), ("basin_id", text), ("tpi_m", number), ("terrain_position", text), ("distance_group", text), ("hab_patch", text), ("habitat_class", text)])
        patch_rows, points_rows, table_rows, labels = [], [], [], []
        mode = self.support.currentData()
        baseline_ids = {j: f"D{i:03d}" for i, group in enumerate(baseline or [], 1) for j in group}
        basin_mode = mode in ("basins", "derived_basins")
        for i, group in enumerate(groups, 1):
            label = f"L{i:03d}"
            labels.append(label)
            points = [records[j][0] for j in group]
            hull = QgsGeometry.fromMultiPointXY(points).convexHull()
            corners = [QgsPointXY(p) for p in hull.vertices()]
            span = max((math.hypot(a.x() - b.x(), a.y() - b.y())
                        for a, b in combinations(corners, 2)), default=0)
            # A small display buffer provides a visible patch for point and line hulls.
            geometry = hull.buffer(distance * 0.10 if distance is not None else 25, 16)
            if geometry.isEmpty() or not geometry.convertToMultiType():
                raise RuntimeError(f"Could not create a patch for {label}.")
            observed = [values[j] for j in group if values[j] is not None]
            elevations = observed if mode in ("elevation", "relief") else (
                [value[0] for value in observed] if mode == "tpi" else []
            )
            basins = {name for value in observed for name in value} if basin_mode else set()
            low, high = (min(elevations), max(elevations)) if elevations else (None, None)
            attrs = [label, len(group), distance, span, threat[0], threat[1], self.event.text().strip(),
                     self.justification.text().strip(), mode, terrain_name, low, high,
                     high - low if elevations else None, ", ".join(sorted(basins)),
                     int(len(basins) > 1) if basins else None, len(group) - len(observed) if mode != "none" else None]
            if mode == "tpi":
                classes = [value[2] for value in observed]
                attrs.extend(classes.count(label) for label in ("Ridge", "Valley bottom", "Intermediate"))
                attrs.extend((self.tpi_radius.value(), self.tpi_threshold.value()))
            else:
                attrs.extend([None] * 5)
            attrs.extend((active_rule, self.basin_threshold.value() if mode == "derived_basins" else None,
                          habitat_class, ", ".join(sorted({item for j in group for item in habitat_ids[j]})) or None))
            patch_rows.append((geometry, attrs))
            table_rows.append((None, attrs))
            for j in group:
                point, source, fid = records[j]
                value = values[j]
                elevation, tpi, position = value if mode == "tpi" and value is not None else (
                    value if mode in ("elevation", "relief") else None, None, None
                )
                points_rows.append((QgsGeometry.fromPointXY(point), [label, source, fid, elevation,
                                    ", ".join(value) if basin_mode and value else None, tpi, position, baseline_ids.get(j), ", ".join(habitat_ids[j]) or None, habitat_class]))
        if pending:
            labels.append("Unassigned")
            for j in pending:
                point, source, fid = records[j]
                points_rows.append((QgsGeometry.fromPointXY(point), ["Unassigned", source, fid, None,
                                    ", ".join(values[j] or ()) if basin_mode else None, None, None, baseline_ids.get(j),
                                    ", ".join(habitat_ids[j]) or None, habitat_class]))
        for layer, rows in ((patches, patch_rows), (assignments, points_rows), (summary, table_rows)):
            _add_rows(layer, rows)
        _style(assignments, labels)
        _style(patches, labels)
        return [assignments, patches, summary]
