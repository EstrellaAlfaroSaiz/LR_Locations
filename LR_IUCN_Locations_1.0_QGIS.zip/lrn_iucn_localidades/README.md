# LRN IUCN Locations 1.0

Install the QGIS ZIP through **Plugins → Manage and Install Plugins → Install from ZIP**.

1. Load your filtered occurrence point layers and a DEM. Tick the point layers to use. All records in each checked layer are evaluated.
2. Select the threat and sub-threat. Set the link distance and document the event and your rationale.
3. For **Terrain support**, choose **Derive sub-basins from DEM** and select the elevation layer. Enter the GRASS flow-accumulation threshold in DEM cells. Use a DEM that covers the upstream study area. You can also choose **Existing watershed polygons**.
4. Select **Distance only** or **Distance within each sub-basin** as the active rule. Click **Preview groups** to compare counts. The Layers panel includes the alternate polygon scenario and, with a DEM, the derived basin and drainage rasters. Toggle those layers to inspect them.
5. Check the point output for its distance-only group and basin assignment. In the basin-restricted scenario, points without a unique basin are marked **Unassigned** and do not add to the location count. The drawn polygons are visual envelopes and may extend beyond basin boundaries.
6. Choose the rule that fits the plausible event and click **Generate final locations**. The final polygons, occurrence assignments and summary are editable QGIS layers. Use QGIS export to keep permanent copies.

DEM derivation uses GRASS r.watershed through QGIS Processing or a local GRASS launcher. If GRASS is unavailable, the existing watershed polygon mode remains available. **Distance references** opens supporting literature inside the plugin. The interface is in English and controls have English and Spanish tooltips.

## Habitat and basin rules

Choose a polygon layer, its habitat field and one class. **Occupied habitat patches** dissolves overlapping and edge-adjacent polygons of that class and counts each occupied patch once. **Occupied sub-basins** counts each uniquely assigned sub-basin once. **Habitat patches within sub-basins** counts occupied patch and basin pairs. These three rules do not use the link distance to count groups. For these rules a fixed 25 m buffer makes point and line groups visible. A valid link distance allows an optional distance-only comparison in the preview. Points outside the selected units or on ambiguous boundaries remain in the occurrence layer as Unassigned. Group geometry is a display envelope. Use **Selected habitat patches** in the Layers panel to inspect the actual habitat polygons.

Choose the rule and DEM scale that match the most serious plausible threat. An occupied patch or basin represents a candidate location when a single plausible event could rapidly affect all occurrences in that unit.

**Distance within each habitat patch**, **Distance within each sub-basin** and **Distance within habitat patches and sub-basins** apply the chosen link distance only to occurrences sharing those units. The selected rule drives both **Preview groups** and **Generate final locations**. In the preview, the distance-only comparison is available as a separate map layer when a valid distance is entered.
