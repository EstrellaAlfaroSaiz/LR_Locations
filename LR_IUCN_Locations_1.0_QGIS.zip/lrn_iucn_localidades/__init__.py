# -*- coding: utf-8 -*-

def classFactory(iface):
    from .localities_plugin import LrnIucnLocalitiesPlugin
    return LrnIucnLocalitiesPlugin(iface)
