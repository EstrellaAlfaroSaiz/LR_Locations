"""Extract basin and drainage rasters using GRASS r.watershed."""
import os
from pathlib import Path
import re
import shutil
import subprocess

from qgis.core import (
    QgsApplication, QgsProcessing, QgsProcessingException, QgsProcessingUtils, QgsRasterLayer,
)


_GRASS_SCRIPT = """
import os
import grass.script as gs

gs.run_command("r.in.gdal", input=os.environ["LRN_DEM"], output="elevation")
gs.run_command("g.region", raster="elevation")
gs.run_command("r.watershed", elevation="elevation", threshold=int(os.environ["LRN_CELLS"]),
               basin="basins", stream="streams")
for name in ("basins", "streams"):
    gs.run_command("r.out.gdal", input=name, output=os.path.join(os.environ["LRN_OUTPUT"], name + ".tif"),
                   format="GTiff", type="Int32", nodata=0)
"""


def _grass_launcher():
    if os.name == "nt":
        root = os.environ.get("OSGEO4W_ROOT")
        if root:
            bin_dir = Path(root) / "bin"
            launchers = [path for path in bin_dir.glob("grass*.bat")
                         if re.fullmatch(r"grass\d+\.bat", path.name)]
            if launchers:
                return str(max(launchers, key=lambda path: int(path.stem[5:])))
    return shutil.which("grass")


def _run_grass(dem, threshold, launcher):
    from osgeo import gdal

    directory = Path(QgsProcessingUtils.generateTempFilename("basins.tif")).parent
    source = directory / "elevation.tif"
    # Stage the selected band through GDAL so only QGIS-generated paths are
    # passed to the launcher, including on Windows batch launchers.
    input_dataset = gdal.Open(dem.source())
    if input_dataset is None:
        raise ValueError("The GRASS launcher requires a DEM readable by GDAL.")
    staged = gdal.Translate(str(source), input_dataset, bandList=[1])
    if staged is None:
        raise RuntimeError("Could not prepare the DEM for GRASS.")
    staged = None
    input_dataset = None
    script = directory / "watershed.py"
    script.write_text(_GRASS_SCRIPT, encoding="utf-8")
    env = dict(os.environ, LRN_DEM=str(source), LRN_CELLS=str(threshold), LRN_OUTPUT=str(directory))
    result = subprocess.run([launcher, "--tmp-project", str(source), "--exec", "python", str(script)],
                            env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, errors="replace", check=False,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if result.returncode or not all((directory / f"{name}.tif").is_file() for name in ("basins", "streams")):
        details = "\n".join(result.stdout.strip().splitlines()[-8:])
        raise RuntimeError(f"GRASS r.watershed failed.\n{details}")
    return {"basin": str(directory / "basins.tif"), "stream": str(directory / "streams.tif")}


def derive_subbasins(dem, threshold):
    registry = QgsApplication.processingRegistry()
    algorithm = next((a for identifier in ("grass:r.watershed", "grass7:r.watershed")
                      if (a := registry.algorithmById(identifier)) is not None), None)
    outputs = None
    error = None
    if algorithm is not None:
        import processing
        try:
            outputs = processing.run(algorithm.id(), {
                "elevation": dem,
                "threshold": threshold,
                "basin": QgsProcessing.TEMPORARY_OUTPUT,
                "stream": QgsProcessing.TEMPORARY_OUTPUT,
            })
        except QgsProcessingException as exc:
            error = exc
    if outputs is None:
        launcher = _grass_launcher()
        if launcher is None:
            raise ValueError(
                "Enable the GRASS Processing provider in QGIS, or choose an existing watershed layer."
                + (f"\n{error}" if error else "")
            )
        outputs = _run_grass(dem, threshold, launcher)
    layers = (
        QgsRasterLayer(str(outputs.get("basin", "")), "DEM sub-basins"),
        QgsRasterLayer(str(outputs.get("stream", "")), "DEM drainage axes"),
    )
    if not all(layer.isValid() for layer in layers):
        raise RuntimeError("The watershed calculation did not return readable rasters.")
    for layer in layers:
        layer.setCustomProperty("lrn_location_output", True)
    return layers
